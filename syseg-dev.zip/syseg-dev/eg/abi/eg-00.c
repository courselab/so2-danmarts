/*
 *    SPDX-FileCopyrightText: 2001 Monaco F. J. <monaco@usp.br>
 *   
 *    SPDX-License-Identifier: GPL-3.0-or-later
 *
 *    This file is part of SYSeg, available at https://gitlab.com/monaco/syseg.
 */

/* eg-00.c - Example code. */
 
#include <stdlib.h>

int b;
int a = 1;

int main()
{
  int c;
  char* d;

  c = 1;
  d = malloc(16);
  
  return 0;
}

