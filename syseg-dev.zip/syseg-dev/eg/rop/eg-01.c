/*
 *    SPDX-FileCopyrightText: 2021 Monaco F. J. <monaco@usp.br>
 *   
 *    SPDX-License-Identifier: GPL-3.0-or-later
 *
 *    This file is part of SYSeg, available at https://gitlab.com/monaco/syseg.
 */

/* eg-01.c - C source file. */
 
int main()
{
  char a[4];
  
  a[0] = 'A';
  a[1] = 'B';
  a[2] = 'C';
  a[3] = 'D';
  
  return 0;
}
