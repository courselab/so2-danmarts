#include "kernel.h"     /* Funções essenciais do kernel. */
#include "kaux.h"       /* Funções auxiliares do kernel. */

/* Endereços onde o cabeçalho do sistema de arquivos e o buffer de diretório serão carregados */
#define FS_HEADER_ADDRESS   0x7C00 
#define DIR_BUFFER_ADDRESS  0x9000  

/* Variáveis globais */
char buffer[BUFF_SIZE];
int go_on = 1;

/* Comandos embutidos */
static struct cmd_t cmds[] = {
    {"help", f_help},
    {"quit", f_quit},
    {"exec", f_exec},
    {"ls", f_list},
    {0, 0}
};

/* Função principal do kernel */
void kmain(void) {
    register_syscall_handler(); /* Registra o manipulador de syscall no int 0x21 */
    splash();       /* Tela de splash desnecessária */
    shell();        /* Inicia o interpretador de linha de comando */
    halt();         /* Na saída, halt */
}

/* Interpretador de linha de comando */
void shell(void) {
    int i;
    clear();
    kwrite("BratOS 1.0\n");

    while (go_on) {
        /* Lê a entrada do usuário. Comandos são tokens ASCII de palavra única sem espaços. */
        do {
            kwrite(PROMPT);
            kread(buffer);
        } while (!buffer[0]);

        /* Verifica comandos embutidos correspondentes */
        i = 0;
        while (cmds[i].funct) {
            if (!strcmp(buffer, cmds[i].name)) {
                cmds[i].funct();
                break;
            }
            i++;
        }

        if (!cmds[i].funct) {
            kwrite("Command not found\n");
        }
    }
}

/* Comando embutido: help */
void f_help(void) {
    kwrite("...me, Charli, you're my only hope!\n\n");
    kwrite("   But we can try also some commands:\n");
    kwrite("      quit    (to exit BratOS)\n");
    kwrite("      ls      (to list files)\n");
    kwrite("      exec    (to exec Hello.bin)\n");
}

/* Comando embutido: quit */
void f_quit(void) {
    kwrite("About to Crash. Bye.");
    go_on = 0;
}

/* Função para listar arquivos */
void f_list(void) {
    struct fs_header_t *fs_header = (struct fs_header_t *)FS_HEADER_ADDRESS;
    directory_entry_t *dir_entry = (directory_entry_t *)((char *)FS_HEADER_ADDRESS + 512 * (fs_header->number_of_boot_sectors + 1));

    kwrite("Listing files:\n");


    for (int i = 0; i < fs_header->number_of_file_entries; i++) {

        if (dir_entry[i].filename[0] != '\0') {
            kwrite("File: ");
            kwrite(dir_entry[i].filename);
            kwrite("\n");
        }
    }
}

void f_exec() {
    char *binary_file_name = "hello.bin";

    // Carrega o cabeçalho do sistema de arquivos
    struct fs_header_t *fs_header = (struct fs_header_t *)FS_HEADER_ADDRESS;

    // Calcula coordenadas para leitura do diretório
    int dirSectorCoord = 1 + fs_header->number_of_boot_sectors;
    int readSectors = fs_header->number_of_file_entries * 32 / 16384 + 1;

    // Offset de memória para o diretório
    int memoryOffset = fs_header->number_of_file_entries * 32 - (readSectors - 1) * 16384;

    // Carrega o diretório na memória
    void *dirSection = (void *)DIR_BUFFER_ADDRESS;
    LerDisco(dirSectorCoord, readSectors, dirSection);

    // Encontra as coordenadas do setor do arquivo binário
    int bin_sector_coordinate = -1;
    for (int i = 0; i < fs_header->number_of_file_entries; i++) {
        char *file_name = (char *)dirSection + i * 32;
        if (!strcmp(file_name, binary_file_name)) {
            bin_sector_coordinate = dirSectorCoord + readSectors + fs_header->max_file_size * i - 1;
            break;
        }
    }

    if (bin_sector_coordinate == -1) {
        kwrite("Binary file not found\n");
        return;
    }

    // Endereço de início do programa na memória
    void *program = (void *)0xFE00;
    void *program_sector_start = program - memoryOffset;

    // Carrega o programa na memória
    LerDisco(bin_sector_coordinate, fs_header->max_file_size, program_sector_start);

    // Chama o ponto de entrada do programa
    __asm__ volatile(
        "call get_returnAddrEbx \n"  // endereço de retorno em ebx
        "push %%ebx \n"              // empurra ebx na pilha
        "jmp *%[progAddr] \n"        // salta para o ponto de entrada do programa

        "get_returnAddrEbx: \n"
        "  mov (%%esp), %%ebx \n"    // move ebx da pilha para ebx
        "  add $17, %%ebx \n"        // ajusta ebx (exemplo hipotético)
        "  ret \n"

        ::[progAddr] "r"(program));
}


