#include "tydos.h"

char name[50];

void main()
{
    puts("Enter your name: ");
    gets(name);
    puts("Hello ");
    puts(name);
}
